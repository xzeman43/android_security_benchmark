rootProject.name = ProjectSettings.projectName
rootProject.buildFileName = "build.gradle.kts"
include(":app")
