package app.vut.secnote.ui.main.profile

import dagger.Module

@Module
class ProfileFragmentModule
