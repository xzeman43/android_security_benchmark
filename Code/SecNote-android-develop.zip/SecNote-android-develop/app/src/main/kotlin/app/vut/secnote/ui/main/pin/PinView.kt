package app.vut.secnote.ui.main.pin

import com.thefuntasty.mvvm.BaseView

interface PinView : BaseView
