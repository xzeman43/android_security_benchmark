package app.vut.secnote.ui.main.login

import dagger.Module

@Module
class LoginFragmentModule
