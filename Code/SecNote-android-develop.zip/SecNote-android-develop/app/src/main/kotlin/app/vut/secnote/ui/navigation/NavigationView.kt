package app.vut.secnote.ui.navigation

import com.thefuntasty.mvvm.BaseView

interface NavigationView : BaseView
