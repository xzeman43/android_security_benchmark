package app.vut.secnote.ui.main.login

import com.thefuntasty.mvvm.BaseView

interface LoginView : BaseView
