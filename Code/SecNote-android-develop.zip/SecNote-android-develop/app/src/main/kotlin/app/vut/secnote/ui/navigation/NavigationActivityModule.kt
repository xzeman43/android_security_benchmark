package app.vut.secnote.ui.navigation

import dagger.Module

@Module
class NavigationActivityModule