package app.vut.secnote.ui.main.profile

import com.thefuntasty.mvvm.BaseView

interface ProfileView : BaseView
