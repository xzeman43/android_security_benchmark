package app.vut.secnote.ui.main.note

import com.thefuntasty.mvvm.BaseView

interface NoteView : BaseView {
    fun addCategory()
}
