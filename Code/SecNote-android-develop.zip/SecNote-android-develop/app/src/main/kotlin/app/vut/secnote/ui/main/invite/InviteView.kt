package app.vut.secnote.ui.main.invite

import com.thefuntasty.mvvm.BaseView

interface InviteView : BaseView
