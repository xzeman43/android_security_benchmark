package app.vut.secnote.data.model.ui

data class CategorySelection(
    val name: String,
    val selected: Boolean
)
