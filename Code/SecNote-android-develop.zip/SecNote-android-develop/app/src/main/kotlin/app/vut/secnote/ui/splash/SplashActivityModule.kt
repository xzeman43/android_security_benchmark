package app.vut.secnote.ui.splash

import dagger.Module

@Module
class SplashActivityModule
