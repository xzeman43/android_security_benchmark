package app.vut.secnote.data.model.ui

enum class StartDestination {
    LOGIN, PIN_SET, PIN_AUTH
}