package app.vut.secnote.ui.main.categories.create

import com.thefuntasty.mvvm.BaseView

interface CreateCategoryView : BaseView
