package app.vut.secnote.ui.main.categories.create

import dagger.Module

@Module
class CreateCategoryFragmentModule
