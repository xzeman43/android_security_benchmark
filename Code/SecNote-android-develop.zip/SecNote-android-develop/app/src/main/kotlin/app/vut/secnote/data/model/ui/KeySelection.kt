package app.vut.secnote.data.model.ui

data class KeySelection(
    val alias: String,
    val selected: Boolean
)
