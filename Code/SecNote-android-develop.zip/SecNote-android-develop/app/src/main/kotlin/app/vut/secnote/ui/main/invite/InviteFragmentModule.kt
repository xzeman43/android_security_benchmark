package app.vut.secnote.ui.main.invite

import dagger.Module

@Module
class InviteFragmentModule
