package app.vut.secnote.ui.main.encryption.create

import dagger.Module

@Module
class CreateKeyFragmentModule {

}
