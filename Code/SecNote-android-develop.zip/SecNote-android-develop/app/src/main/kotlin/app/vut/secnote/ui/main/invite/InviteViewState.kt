package app.vut.secnote.ui.main.invite

import com.thefuntasty.mvvm.ViewState
import javax.inject.Inject

class InviteViewState @Inject constructor() : ViewState
