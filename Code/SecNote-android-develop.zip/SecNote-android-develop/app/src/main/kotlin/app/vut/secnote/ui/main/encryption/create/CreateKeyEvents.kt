package app.vut.secnote.ui.main.encryption.create

import com.thefuntasty.mvvm.event.Event

sealed class CreateKeyEvent : Event<CreateKeyViewState>()
object NavigateBackEvent : CreateKeyEvent()
