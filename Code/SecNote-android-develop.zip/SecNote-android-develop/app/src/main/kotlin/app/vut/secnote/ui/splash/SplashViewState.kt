package app.vut.secnote.ui.splash

import com.thefuntasty.mvvm.ViewState
import javax.inject.Inject

class SplashViewState @Inject constructor() : ViewState
