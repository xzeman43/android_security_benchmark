package app.vut.secnote.ui.main.encryption.create

import com.thefuntasty.mvvm.BaseView

interface CreateKeyView : BaseView
