package app.vut.secnote.ui.main.categories

import com.thefuntasty.mvvm.BaseView

interface CategoriesView : BaseView
