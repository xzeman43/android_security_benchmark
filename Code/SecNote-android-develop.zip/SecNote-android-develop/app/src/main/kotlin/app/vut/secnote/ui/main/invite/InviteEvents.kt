package app.vut.secnote.ui.main.invite

import com.thefuntasty.mvvm.event.Event

sealed class InviteEvent : Event<InviteViewState>()
