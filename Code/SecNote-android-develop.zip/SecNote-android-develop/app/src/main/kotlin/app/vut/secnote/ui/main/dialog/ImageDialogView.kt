package app.vut.secnote.ui.main.dialog

import com.thefuntasty.mvvm.BaseView

interface ImageDialogView : BaseView
