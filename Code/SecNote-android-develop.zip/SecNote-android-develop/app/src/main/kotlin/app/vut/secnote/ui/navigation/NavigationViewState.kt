package app.vut.secnote.ui.navigation

import com.thefuntasty.mvvm.ViewState
import javax.inject.Inject

class NavigationViewState @Inject constructor() : ViewState
