package app.vut.secnote.data.model.ui

enum class PinState {
    PIN_SET, AUTHORISE, REAUTHORISE,
}