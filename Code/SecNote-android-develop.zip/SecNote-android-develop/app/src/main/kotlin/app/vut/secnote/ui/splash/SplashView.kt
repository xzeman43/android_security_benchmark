package app.vut.secnote.ui.splash

import com.thefuntasty.mvvm.BaseView

interface SplashView : BaseView
