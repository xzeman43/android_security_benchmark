package repository

import "noteservice/internal/persistance/database"

func ProvideNoteRepository(database *database.Database) *NoteRepository {
	return &NoteRepository{database: database}
}
