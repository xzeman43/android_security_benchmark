package service

import (
	"context"
	"noteservice/api/noteservice"
	"noteservice/internal/repository"
)

type NoteService struct {
	noteRepository *repository.NoteRepository
}

func (n *NoteService) GetNotes(context context.Context, request *noteservice.NoteRequest) (*noteservice.NoteResponse, error) {
	return n.noteRepository.GetNotes(context, request)
}

func (n *NoteService) CreateNote(context context.Context, request *noteservice.NoteOperationRequest) (*noteservice.Note, error) {
	return n.noteRepository.CreateNote(context, request)
}

func (n *NoteService) UpdateNote(context context.Context, request *noteservice.NoteOperationRequest) (*noteservice.Note, error) {
	return n.noteRepository.UpdateNote(context, request)
}

func (n *NoteService) DeleteNote(context context.Context, request *noteservice.DeleteRequest) (*noteservice.Response, error) {
	return n.noteRepository.DeleteNote(context, request)
}
