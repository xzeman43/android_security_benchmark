package service

import "noteservice/internal/repository"

func ProvideNoteService(noteRepository *repository.NoteRepository) *NoteService {
	return &NoteService{
		noteRepository: noteRepository,
	}
}
