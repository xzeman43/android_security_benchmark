package model

import "noteservice/api/noteservice"

type Note struct {
	Id         string   `json:"id" bson:"_id,omitempty"`
	Title      string   `json:"title" bson:"title,omitempty"`
	Body       string   `json:"body" bson:"body"`
	Categories []string `json:"categories" bson:"categories"`
	Encrypted  bool     `json:"encrypted" bson:"encrypted"`
	Alias      string   `json:"alias" bson:"alias"`
}

func (note *Note) ConvertToServiceNote() *noteservice.Note {
	return &noteservice.Note{
		Id:         note.Id,
		Title:      note.Title,
		Body:       note.Body,
		Categories: note.Categories,
		Encrypted:  note.Encrypted,
		Alias:      note.Alias,
	}
}
