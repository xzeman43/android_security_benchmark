//+build wireinject

package di

import (
	"noteservice/internal/persistance/database"
	"noteservice/internal/repository"
	"noteservice/internal/service"
)
import "github.com/google/wire"

func WireAppComponent() *service.NoteService {
	wire.Build(
		database.ProvideConfigProduction,
		database.ProvideDatabase,
		repository.ProvideNoteRepository,
		service.ProvideNoteService,
	)
	return &service.NoteService{}
}

func WireAppComponentDev() *service.NoteService {
	wire.Build(
		database.ProvideConfigDevelopment,
		database.ProvideDatabase,
		repository.ProvideNoteRepository,
		service.ProvideNoteService,
	)
	return &service.NoteService{}
}

func WireAppComponentTesting() *service.NoteService {
	wire.Build(
		database.ProvideTestDatabase,
		repository.ProvideNoteRepository,
		service.ProvideNoteService,
	)
	return &service.NoteService{}
}
