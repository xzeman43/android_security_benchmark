#!/bin/bash
docker build -t secnote-noteservice -f build/Dockerfile .
