#!/bin/bash

protoc api/noteservice/noteservice.proto --go_out=plugins=grpc:./
protoc api/secnote/errors.proto --go_out=plugins=grpc:./
