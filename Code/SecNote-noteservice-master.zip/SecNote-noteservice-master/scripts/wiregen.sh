#!/bin/bash
#Requires go get github.com/google/wire/cmd/wire

cd internal/di
wire