package tools

import (
	"authservice/api/secnote"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func ConvertError(code codes.Code, message string, err error) error {
	appError := secnote.ServiceError{
		Message: message,
		Cause:   err.Error(),
	}
	return status.Error(code, appError.String())
}

func CreateError(code codes.Code, message string, cause string) error {
	appError := secnote.ServiceError{
		Message: message,
		Cause:   cause,
	}
	return status.Error(code, appError.String())
}
