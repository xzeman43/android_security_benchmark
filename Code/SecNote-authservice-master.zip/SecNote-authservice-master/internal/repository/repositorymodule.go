package repository

import (
	"authservice/internal/model"
	"authservice/internal/persistance/database"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"gopkg.in/square/go-jose.v2"
)

func ProvideAuthRepository(database *database.Database) *AuthRepository {
	return &AuthRepository{
		Database: database,
	}
}

func ProvideCryptoRepository(jwtCrypto *model.JwtCrypto) *CryptoRepository {
	return &CryptoRepository{
		JwtCrypto: jwtCrypto,
	}
}

func ProvideSigned() *model.JwtCrypto {
	ecdsaKey, _ := ecdsa.GenerateKey(elliptic.P521(), rand.Reader)
	key := jose.SigningKey{Algorithm: jose.ES512, Key: ecdsaKey}
	var options = jose.SignerOptions{}
	options.WithType("JWT")
	ecSigner, err := jose.NewSigner(key, &options)
	if err != nil {
		panic(err)
	}

	return &model.JwtCrypto{
		Signer: ecSigner,
		Key:    ecdsaKey,
	}
}
