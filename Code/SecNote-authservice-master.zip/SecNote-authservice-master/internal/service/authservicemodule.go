package service

import "authservice/internal/repository"

func ProvideAuthService(repository *repository.AuthRepository, crypto *repository.CryptoRepository) *AuthService {
	return &AuthService{
		Repository: repository,
		Crypto:     crypto,
	}
}
