//+build wireinject

package di

import (
	"authservice/internal/persistance/database"
	"authservice/internal/repository"
	"authservice/internal/service"
	"github.com/google/wire"
)

func WireAppComponent() *service.AuthService {
	wire.Build(
		database.ProvideConfigProduction,
		database.ProvideDatabase,
		repository.ProvideAuthRepository,
		repository.ProvideCryptoRepository,
		repository.ProvideSigned,
		service.ProvideAuthService,
	)
	return &service.AuthService{}
}

func WireAppComponentDev() *service.AuthService {
	wire.Build(
		database.ProvideConfigDevelopment,
		database.ProvideDatabase,
		repository.ProvideAuthRepository,
		repository.ProvideCryptoRepository,
		repository.ProvideSigned,
		service.ProvideAuthService,
	)
	return &service.AuthService{}
}

func WireAppComponentTesting() *service.AuthService {
	wire.Build(
		database.ProvideTestDatabase,
		repository.ProvideAuthRepository,
		repository.ProvideCryptoRepository,
		repository.ProvideSigned,
		service.ProvideAuthService,
	)
	return &service.AuthService{}
}
