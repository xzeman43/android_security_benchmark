package config

import "os"

type DbConfigProduction struct {
}

func (*DbConfigProduction) User() string {
	return os.Getenv("DB_USER")
}

func (*DbConfigProduction) Password() string {
	return os.Getenv("DB_PASSWORD")
}

func (*DbConfigProduction) HostName() string {
	return os.Getenv("DB_HOST")
}

func (*DbConfigProduction) Port() string {
	return os.Getenv("DB_PORT")
}

func (*DbConfigProduction) Scheme() string {
	return "mongodb"
}

func (*DbConfigProduction) DatabaseName() string {
	return "auth_service_prod"
}
