package config

type DbConfig interface {
	HostName() string
	Port() string
	Scheme() string
	DatabaseName() string
	User() string
	Password() string
}
