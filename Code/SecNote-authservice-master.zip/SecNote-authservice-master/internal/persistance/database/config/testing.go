package config

type DbConfigTesting struct {
}

func (*DbConfigTesting) User() string {
	return "admin"
}

func (*DbConfigTesting) Password() string {
	return "password"
}

func (*DbConfigTesting) HostName() string {
	return "localhost"
}

func (*DbConfigTesting) Port() string {
	return "27017"
}

func (*DbConfigTesting) Scheme() string {
	return "mongodb"
}

func (*DbConfigTesting) DatabaseName() string {
	return "auth_service_testing"
}
