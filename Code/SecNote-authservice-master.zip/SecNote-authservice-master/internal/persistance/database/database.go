package database

import (
	"authservice/internal/persistance/database/config"
	"go.mongodb.org/mongo-driver/mongo"
)

type Database struct {
	Client        *mongo.Database
	Configuration config.DbConfig
}
