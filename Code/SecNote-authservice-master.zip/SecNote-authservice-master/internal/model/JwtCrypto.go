package model

import (
	"crypto/ecdsa"
	"gopkg.in/square/go-jose.v2"
)

type JwtCrypto struct {
	Signer jose.Signer
	Key    *ecdsa.PrivateKey
}
