package model

import "github.com/amsokol/mongo-go-driver-protobuf/pmongo"

type User struct {
	Id               *pmongo.ObjectId `json:"id" bson:"_id,omitempty"`
	LastSignIn       int64
	AccountCreatedAt int64
	Email            string
	Password         string
	Key              string
}
