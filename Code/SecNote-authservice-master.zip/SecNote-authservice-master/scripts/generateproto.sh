#!/bin/bash

protoc api/authservice/authservice.proto --go_out=plugins=grpc:./
protoc api/secnote/errors.proto --go_out=plugins=grpc:./
