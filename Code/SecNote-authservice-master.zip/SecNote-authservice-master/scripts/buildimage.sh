#!/bin/bash
docker build -t secnote-authservice -f build/Dockerfile .
