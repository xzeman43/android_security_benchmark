package repository

import "permissionservice/internal/persistance/database"

func ProvidePermissionRepository(database *database.Database) *PermissionRepository {
	return &PermissionRepository{
		Database: database,
	}
}
