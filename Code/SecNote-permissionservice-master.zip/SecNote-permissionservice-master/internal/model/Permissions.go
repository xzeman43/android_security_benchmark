package model

import "permissionservice/api/permissionservice"

type Permissions struct {
	Read   bool
	Write  bool
	Delete bool
	Share  bool
	Owner  bool
}

func ConvertToServicePermissions(p *permissionservice.Permissions) *Permissions {
	return &Permissions{
		Read:   p.Read,
		Write:  p.Write,
		Delete: p.Delete,
		Share:  p.Share,
		Owner:  p.Owner,
	}
}
