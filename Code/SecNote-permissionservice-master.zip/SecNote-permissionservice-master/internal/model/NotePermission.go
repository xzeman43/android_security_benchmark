package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type NotePermission struct {
	Id          *primitive.ObjectID `json:"id" bson:"_id,omitempty"`
	UserId      string              `json:"userId" bson:"userId,omitempty"`
	NoteId      string              `json:"noteId" bson:"noteId,omitempty"`
	Permissions Permissions         `json:"permissions" bson:"permissions,omitempty"`
}
