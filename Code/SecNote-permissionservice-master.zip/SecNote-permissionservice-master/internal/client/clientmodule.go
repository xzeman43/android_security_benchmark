package client

import (
	"github.com/grpc-ecosystem/go-grpc-middleware/tracing/opentracing"
	"github.com/opentracing/opentracing-go"
	"google.golang.org/grpc"
	"permissionservice/api/authservice"
	"permissionservice/api/noteservice"
)

const (
	NoteClient = "noteservice:9091"
	AuthClient = "authservice:9090"
)

func ProvideNoteClient() noteservice.NoteServiceClient {
	streamOpts := grpc.WithStreamInterceptor(
		grpc_opentracing.StreamClientInterceptor(
			grpc_opentracing.WithTracer(opentracing.GlobalTracer())))
	unaryOpts := grpc.WithUnaryInterceptor(
		grpc_opentracing.UnaryClientInterceptor(
			grpc_opentracing.WithTracer(opentracing.GlobalTracer())))
	conn, err := grpc.Dial(NoteClient, grpc.WithInsecure(), streamOpts, unaryOpts)
	if err != nil {
		panic(err)
	}
	return noteservice.NewNoteServiceClient(conn)
}

func ProvideAuthClient() authservice.AuthServiceClient {
	streamOpts := grpc.WithStreamInterceptor(
		grpc_opentracing.StreamClientInterceptor(
			grpc_opentracing.WithTracer(opentracing.GlobalTracer())))
	unaryOpts := grpc.WithUnaryInterceptor(
		grpc_opentracing.UnaryClientInterceptor(
			grpc_opentracing.WithTracer(opentracing.GlobalTracer())))
	conn, err := grpc.Dial(AuthClient, grpc.WithInsecure(), streamOpts, unaryOpts)
	if err != nil {
		panic(err)
	}
	return authservice.NewAuthServiceClient(conn)
}
