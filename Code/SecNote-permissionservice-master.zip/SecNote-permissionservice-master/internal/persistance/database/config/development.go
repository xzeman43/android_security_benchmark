package config

type DbConfigDevelopment struct {
}

func (*DbConfigDevelopment) User() string {
	return "admin"
}

func (*DbConfigDevelopment) Password() string {
	return "password"
}

func (*DbConfigDevelopment) HostName() string {
	return "localhost"
}

func (*DbConfigDevelopment) Port() string {
	return "27017"
}

func (*DbConfigDevelopment) Scheme() string {
	return "mongodb"
}

func (*DbConfigDevelopment) DatabaseName() string {
	return "permission_service_dev"
}
