package database

import (
	"go.mongodb.org/mongo-driver/mongo"
	"permissionservice/internal/persistance/database/config"
)

type Database struct {
	Client        *mongo.Database
	Configuration config.DbConfig
}
