package service

import (
	"permissionservice/api/authservice"
	"permissionservice/api/noteservice"
	"permissionservice/internal/repository"
)

func ProvidePermissionService(
	permissionRepository *repository.PermissionRepository,
	authClient authservice.AuthServiceClient,
	noteClient noteservice.NoteServiceClient) *PermissionService {
	return &PermissionService{
		AuthClient:           authClient,
		NoteClient:           noteClient,
		PermissionRepository: permissionRepository,
	}
}
