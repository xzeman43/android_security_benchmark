//+build wireinject

package di

import (
	"github.com/google/wire"
	"permissionservice/internal/client"
	"permissionservice/internal/persistance/database"
	"permissionservice/internal/repository"
	"permissionservice/internal/service"
)

func WireAppComponent() *service.PermissionService {
	wire.Build(
		client.ProvideAuthClient,
		client.ProvideNoteClient,
		database.ProvideConfigProduction,
		database.ProvideDatabase,
		repository.ProvidePermissionRepository,
		service.ProvidePermissionService,
	)
	return &service.PermissionService{}
}

func WireAppComponentDev() *service.PermissionService {
	wire.Build(
		client.ProvideAuthClient,
		client.ProvideNoteClient,
		database.ProvideConfigDevelopment,
		database.ProvideDatabase,
		repository.ProvidePermissionRepository,
		service.ProvidePermissionService,
	)
	return &service.PermissionService{}
}
