#!/bin/bash
docker build -t secnote-permissionservice -f build/Dockerfile .
