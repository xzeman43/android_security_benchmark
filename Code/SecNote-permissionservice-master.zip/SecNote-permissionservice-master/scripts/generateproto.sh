#!/bin/bash

protoc api/permissionservice/permissionservice.proto --go_out=plugins=grpc:./
protoc api/authservice/authservice.proto --go_out=plugins=grpc:./
protoc api/secnote/errors.proto --go_out=plugins=grpc:./
protoc api/noteservice/noteservice.proto --go_out=plugins=grpc:./
